#/bin/sh
create-package.sh
eap-install.sh remove
eap-install.sh install
eap-install.sh start
