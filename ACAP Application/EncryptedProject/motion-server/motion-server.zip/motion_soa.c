/**
 * @file ax_event_subscription_example.c
 *
 * @brief This example illustrates how to setup an subscription to the
 * manual trigger event.
 *
 * Error handling has been omitted for the sake of brevity.
 */

#include <glib.h>
#include <glib-object.h>
#include <axsdk/axevent.h>
#include <syslog.h>
#include <time.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
//capture part
#include <capture.h>
#include <syslog.h>

#define SERVER_PROTOCOL 0
#define SERVER_PORT 10800
#define SERVER_ADDRESS "192.168.0.1"

static int motion;

static void
subscription_callback(guint subscription,
    AXEvent *event, guint *token);

static guint
subscribe_to_vmd3(AXEventHandler *event_handler, guint *token);

static void appendToFile(char* path, void *data, int size);
static void logDateTime(char* path, int action);

#if 0
int buffToInt(unsigned char *buffer)
{
	int num = (int)((unsigned char)(buffer[0]) << 24 | (unsigned char)(buffer[1]) << 16 | (unsigned char)(buffer[2]) << 8 | (unsigned char)(buffer[3]));
	return num;
}

void intToBuff(int n,unsigned char* buffer) {
	buffer[0] = (n >> 24) & 0xFF;
	buffer[1] = (n >> 16) & 0xFF;
	buffer[2] = (n >> 8) & 0xFF;
	buffer[3] = n & 0xFF;
}

void writeBytes(unsigned char* dataBytes, int len, int client_sockfd){
	//write 4 bytes for len
	//len =  (int)htonl((unsigned int)len);
	unsigned char lenBytes[4];
	intToBuff(len,lenBytes);
	//write(client_sockfd,&len,sizeof(len));
	write(client_sockfd,lenBytes,4);
	syslog(LOG_INFO,"server write 4 len bytes");

	//write data bytes
	if(len > 0)
		write(client_sockfd,dataBytes,len);
	syslog(LOG_INFO,"server write %d data len bytes", len);
}

unsigned char* readBytes(int* len,int client_sockfd){
	//read 4 bytes for int
	unsigned char lenBytes[4];
	read(client_sockfd, &lenBytes,4);
	*len = buffToInt(lenBytes);
	syslog(LOG_INFO,"server read 4 len bytes");

	//read data bytes
	unsigned char *dataBytes = malloc(*len);
	if(*len > 0)
		read(client_sockfd, dataBytes,*len);
	syslog(LOG_INFO,"server read data len bytes");
	return dataBytes;
}
unsigned char* readBinaryFile(int* len,char* path){
	//https://stackoverflow.com/questions/22059189/read-a-file-as-byte-array
	FILE *fileptr;
	unsigned char *buffer;
	fileptr = fopen(path, "rb");  // Open the file in binary mode
	fseek(fileptr, 0, SEEK_END);          // Jump to the end of the file
	*len = (int)ftell(fileptr);           // Get the current byte offset in the file
	rewind(fileptr);                      // Jump back to the beginning of the file

	//buffer = (unsigned char *)malloc((*len+1)*sizeof(unsigned char)); // Enough memory for file + \0
	buffer = (unsigned char *)malloc((*len)*sizeof(unsigned char)); // Enough memory for file + \0
	fread(buffer, *len, 1, fileptr); // Read in the entire file
	fclose(fileptr); // Close the file
	//if(*len > 0){
	//	*len++; //for \0
	//}
	return buffer;
}
#endif
static void write_jpeg(void *data, char* path,int size){
	syslog(LOG_INFO,"STEP IN WRITING");
	FILE *fp;
	fp = fopen(path, "w");
	int i;
	for(i=0; i<size; i++){
		fputc(((unsigned char *)data)[i], fp);
	}
	fclose(fp);
}

static void send_jpeg(unsigned char* instruction,int fps, int client_sockfd){
	media_frame  *frame;
	void     *data;
	int   size;
	media_stream *stream;
	//capture_time timestamp;
	//syslog(LOG_INFO,"STEP START");
	syslog(LOG_INFO,"INSTRUCTION: %s",instruction);
	int msec = (int)(1000000.0/fps);
	syslog(LOG_INFO,"sleep msec: %d",msec);
	(void)client_sockfd;
	
	//JPEG
	stream = capture_open_stream(IMAGE_JPEG, (const char *)instruction);
	syslog(LOG_INFO,"STEP STREAM");
	
//	while(1){
		frame  = capture_get_frame(stream);
		data      = capture_frame_data(frame);//our picture
		syslog(LOG_INFO,"STEP DATA");
		size = (int)capture_frame_size(frame);
		syslog(LOG_INFO,"STEP SIZE");
//		writeBytes(data, size, client_sockfd);
//		usleep((useconds_t)msec);
		capture_frame_free(frame);
//	}
	//END while
	write_jpeg(data, "tmp/test.jpeg",(int)size);

	capture_close_stream(stream);
	//return (unsigned char*)data;
}

#if 0
void childProcess(int client_sockfd){
	syslog(LOG_INFO,"child process\n");
	int len;

	//read instruction
	unsigned char *instruction = readBytes(&len, client_sockfd);
	syslog(LOG_INFO, "instruction %s\n", instruction);

	unsigned char *fpsBytes = readBytes(&len, client_sockfd);
	int fps = buffToInt(fpsBytes);
	syslog(LOG_INFO, "fps %d\n", fps);

	send_jpeg(instruction, fps, client_sockfd);

	free(instruction);
	//unsigned char send[] = "server to client 12";
	//writeBytes(send, sizeof(send), client_sockfd);

	close(client_sockfd);
	exit(0);
}


int create_socket()
{
	int server_sockfd, client_sockfd;
	int server_len,client_len;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;

	server_sockfd = socket(AF_INET, SOCK_STREAM,0);

	server_address.sin_family = AF_INET;

	server_address.sin_addr.s_addr = htonl(INADDR_ANY);
	server_address.sin_port = htons(10800);
	server_len = sizeof(server_address);
	bind(server_sockfd, (struct sockaddr *) &server_address, server_len);

	listen(server_sockfd, 5);
	signal(SIGCHLD, SIG_IGN);
	
	while(1) {
		syslog(LOG_INFO,"server IS waiting\n");
		client_len = sizeof(client_address);
		syslog(LOG_INFO,"server IS waiting 1\n");
		client_sockfd = accept(server_sockfd, (struct sockaddr *)&client_address,(socklen_t *)&client_len);
		syslog(LOG_INFO,"server IS waiting 2\n");
                
		if(fork() == 0) {
			syslog(LOG_INFO,"server IS child\n");
			childProcess(client_sockfd);
          	}
		else 
		{
			syslog(LOG_INFO,"server IS parent\n");
			close(client_sockfd);
     		}
	}

}
#endif



static void
subscription_callback(guint subscription,
    AXEvent *event, guint *token)
{
  const AXEventKeyValueSet *key_value_set;
  gboolean state;
  GError *error;
  GTimeVal timeval;
  unsigned char t = 0;

  /* The subscription id is not used in this example. */
  (void)subscription;

  /* Extract the AXEventKeyValueSet from the event. */
  key_value_set = ax_event_get_key_value_set(event);


  /* Get the state of the motion detection . */
  if (ax_event_key_value_set_get_boolean(key_value_set,
        "active", NULL, &state, &error)) {

    /* Print a helpfull message. */
	char path[] = "/var/log/motion.log";

    if (state) {
      g_get_current_time(&timeval);
      send_jpeg(&t,1,1);
      syslog(LOG_INFO,"Camera has detected motion!!!!");
      logDateTime(path, 1);
      motion = 1;
    } else {
      if (motion) {
         syslog(LOG_INFO,"Detected motion stopped !!!!");
	 logDateTime(path, 0);
         motion = 0;
      }
    }
  } else {
     syslog(LOG_ERR,"Error:%s ", error->message);
     g_error_free(error);
  }

  g_message("Here is th token:%d\n", *token);
}

static guint
subscribe_to_vmd3(AXEventHandler *event_handler, guint *token)
{
  AXEventKeyValueSet *key_value_set;
  guint subscription;

  key_value_set = ax_event_key_value_set_new();

  ax_event_key_value_set_add_key_values(key_value_set,
	NULL,
	"topic0", "tns1", "RuleEngine", AX_VALUE_TYPE_STRING,
	"topic1", "tnsaxis", "VMD3", AX_VALUE_TYPE_STRING,
	"active", NULL, NULL, AX_VALUE_TYPE_BOOL, NULL);

  /* Time to setup the subscription. Use the "token" input argument as
   * input data to the callback function "subscription callback"
   */
  ax_event_handler_subscribe(event_handler, key_value_set,
        &subscription, (AXSubscriptionCallback)subscription_callback, token,
        NULL);

  /* The key/value set is no longer needed */
  ax_event_key_value_set_free(key_value_set);

  return subscription;
}

static void appendToFile(char* path, void *data, int size){
	FILE *fp;
	fp = fopen(path, "a");
	int i;
	for(i=0; i<size; i++){
		fputc(((unsigned char *)data)[i], fp);
	}
	fclose(fp);
}


static void logDateTime(char* path, int action){
	time_t timer;
	char buffer[26];
	struct tm* tm_info;

	time(&timer);
	tm_info = localtime(&timer);

	strftime(buffer, 26, "%Y-%m-%dT%H:%M:%S;", tm_info);
	appendToFile(path, buffer, 20);
	if(action)
		appendToFile(path, "1\n", 2);
	else
		appendToFile(path, "0\n", 2);
}


int main(void)
{
  GMainLoop *main_loop;
  AXEventHandler *event_handler;
  guint token = 1234;
  guint subscription;
  openlog(NULL, LOG_PID, LOG_DAEMON);

  main_loop = g_main_loop_new(NULL, FALSE);

  event_handler = ax_event_handler_new();

  subscription = subscribe_to_vmd3(event_handler, &token);
  if(!subscription)
  {
    syslog(LOG_ERR, "Motion Dection Subscription Failed");
  }


  g_main_loop_run(main_loop);

  ax_event_handler_unsubscribe(event_handler, subscription, NULL);

  ax_event_handler_free(event_handler);

  closelog();

  return 0;
}

